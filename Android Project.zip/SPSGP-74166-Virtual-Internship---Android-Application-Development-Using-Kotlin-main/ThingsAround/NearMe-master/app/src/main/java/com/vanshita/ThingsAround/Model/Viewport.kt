package com.gopal.ThingsAround.Model

class Viewport {

    var northeast:Northeast?=null
    var southwest:Southwest?=null
}