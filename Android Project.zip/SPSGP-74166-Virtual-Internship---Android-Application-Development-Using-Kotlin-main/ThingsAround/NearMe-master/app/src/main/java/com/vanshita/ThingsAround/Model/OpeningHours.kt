package com.gopal.ThingsAround.Model

class OpeningHours {
    var open_now:Boolean=false
}