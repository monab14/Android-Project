package com.gopal.ThingsAround;

import android.app.Activity;

public class PlaceDetails extends Activity {
}
