package com.gopal.ThingsAround.Model

class Geometry {

    var viewport:Viewport?=null
    var location:Location?=null
}